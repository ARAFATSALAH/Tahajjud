منبه التهجد - Android (Kotlin + Compose)

طريقة 1 (بدون Android Studio):
1) أنشئ repository جديد على GitHub وارفع محتوى هذا المجلد كله (بما فيه .github).
2) تبويب Actions -> Build APK -> Run workflow.
3) بعد ما يخلص: نزّل Tahajjud-APK من Artifacts، فك الضغط، وثبّت app-debug.apk على تلفونك.

طريقة 2: افتح المجلد بـ Android Studio واعمل Run (Gradle 8.9، JDK 17).
