package com.arafat.tahajjud

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.Instant

object Scheduler {
    const val ACTION_ALARM = "com.arafat.tahajjud.ALARM"
    private const val CODE_MAIN = 1
    private const val CODE_SNOOZE = 2

    fun scheduleNext(ctx: Context) {
        val prefs = Prefs(ctx)
        val am = ctx.getSystemService(AlarmManager::class.java)
        if (!prefs.enabled) {
            am.cancel(alarmIntent(ctx, CODE_MAIN))
            return
        }
        val plan = PrayerCalc.plan(
            Instant.now(), prefs.lat, prefs.lng,
            prefs.fajrAngle.toDouble(), prefs.mode, prefs.offset
        ) ?: return
        schedule(ctx, plan.alarm.toEpochMilli(), CODE_MAIN)
    }

    fun scheduleSnooze(ctx: Context, minutes: Int) {
        schedule(ctx, System.currentTimeMillis() + minutes * 60_000L, CODE_SNOOZE)
    }

    private fun schedule(ctx: Context, atMillis: Long, code: Int) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val show = PendingIntent.getActivity(
            ctx, 10, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(atMillis, show), alarmIntent(ctx, code))
    }

    private fun alarmIntent(ctx: Context, code: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code,
            Intent(ctx, AlarmReceiver::class.java).setAction(ACTION_ALARM),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
}
