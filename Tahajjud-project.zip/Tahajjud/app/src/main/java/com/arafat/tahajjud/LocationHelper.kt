package com.arafat.tahajjud

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat

object LocationHelper {

    private fun save(ctx: Context, loc: Location) {
        val p = Prefs(ctx)
        p.lat = loc.latitude
        p.lng = loc.longitude
        p.hasLocation = true
    }

    @SuppressLint("MissingPermission")
    fun refresh(ctx: Context, onDone: (Boolean) -> Unit) {
        val granted =
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!granted) { onDone(false); return }

        val lm = ctx.getSystemService(LocationManager::class.java)
        val providers = lm.getProviders(true)
        val last = providers.mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
        if (last != null) { save(ctx, last); onDone(true); return }

        val provider = providers.firstOrNull { it != LocationManager.PASSIVE_PROVIDER }
        if (provider == null) { onDone(false); return }
        LocationManagerCompat.getCurrentLocation(
            lm, provider, null, ContextCompat.getMainExecutor(ctx)
        ) { loc ->
            if (loc != null) { save(ctx, loc); onDone(true) } else onDone(false)
        }
    }
}
