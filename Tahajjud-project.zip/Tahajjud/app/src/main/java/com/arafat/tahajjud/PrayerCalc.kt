package com.arafat.tahajjud

import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

/** حساب المغرب والفجر (خوارزمية فلكية قياسية) ثم منتصف الليل والثلث الأخير. */
object PrayerCalc {

    data class Night(val maghrib: Instant, val nextFajr: Instant) {
        private val length: Duration get() = Duration.between(maghrib, nextFajr)
        val midnight: Instant get() = maghrib.plus(length.dividedBy(2))
        val lastThirdStart: Instant get() = nextFajr.minus(length.dividedBy(3))
    }

    data class Plan(val night: Night, val alarm: Instant)

    private fun rad(d: Double) = Math.toRadians(d)
    private fun deg(r: Double) = Math.toDegrees(r)
    private fun fixAngle(a: Double) = ((a % 360.0) + 360.0) % 360.0
    private fun fixHour(h: Double) = ((h % 24.0) + 24.0) % 24.0

    private fun julian(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    /** returns declination (deg) and equation of time (hours) */
    private fun sun(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(rad(g)) + 0.020 * sin(rad(2 * g)))
        val e = 23.439 - 0.00000036 * d
        val ra = fixHour(deg(atan2(cos(rad(e)) * sin(rad(l)), cos(rad(l)))) / 15.0)
        val eqt = q / 15.0 - ra
        val decl = deg(asin(sin(rad(e)) * sin(rad(l))))
        return decl to eqt
    }

    /** local solar time (hours) when the sun is `angle` degrees below horizon */
    private fun angleTime(angle: Double, startHour: Double, jd: Double, lat: Double, before: Boolean): Double? {
        var t = startHour / 24.0
        for (i in 0 until 3) {
            val (decl, eqt) = sun(jd + t)
            val z = fixHour(12.0 - eqt)
            val x = (-sin(rad(angle)) - sin(rad(decl)) * sin(rad(lat))) / (cos(rad(decl)) * cos(rad(lat)))
            if (x < -1.0 || x > 1.0) return null
            val v = deg(acos(x)) / 15.0
            val time = z + if (before) -v else v
            t = time / 24.0
        }
        return t * 24.0
    }

    private fun toInstant(date: LocalDate, lng: Double, localHour: Double): Instant {
        val utcHours = localHour - lng / 15.0
        return date.atStartOfDay(ZoneOffset.UTC).toInstant().plusMillis((utcHours * 3_600_000.0).toLong())
    }

    private fun jdFor(date: LocalDate, lng: Double) =
        julian(date.year, date.monthValue, date.dayOfMonth) - lng / 360.0

    fun fajr(date: LocalDate, lat: Double, lng: Double, angle: Double): Instant? =
        angleTime(angle, 5.0, jdFor(date, lng), lat, true)?.let { toInstant(date, lng, it) }

    fun maghrib(date: LocalDate, lat: Double, lng: Double): Instant? =
        angleTime(0.833, 18.0, jdFor(date, lng), lat, false)?.let { toInstant(date, lng, it) }

    /** الليل الذي يبدأ بمغرب هذا اليوم وينتهي بفجر اليوم التالي */
    fun night(date: LocalDate, lat: Double, lng: Double, angle: Double): Night? {
        val m = maghrib(date, lat, lng) ?: return null
        val f = fajr(date.plusDays(1), lat, lng, angle) ?: return null
        return Night(m, f)
    }

    /** mode: 0 = الثلث الأخير، 1 = منتصف الليل */
    fun trigger(n: Night, mode: Int, offsetMin: Int): Instant {
        val base = if (mode == 1) n.midnight else n.lastThirdStart
        return base.minusSeconds(offsetMin * 60L)
    }

    fun plan(now: Instant, lat: Double, lng: Double, angle: Double, mode: Int, offsetMin: Int): Plan? {
        val today = now.atZone(ZoneOffset.UTC).toLocalDate()
        val nights = (-1L..2L).mapNotNull { night(today.plusDays(it), lat, lng, angle) }
        val current = nights.firstOrNull { it.nextFajr.isAfter(now) } ?: return null
        val alarm = nights.map { trigger(it, mode, offsetMin) }
            .filter { it.isAfter(now.plusSeconds(30)) }
            .minOrNull() ?: return null
        return Plan(current, alarm)
    }
}
