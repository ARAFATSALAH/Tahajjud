package com.arafat.tahajjud

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                        Screen()
                    }
                }
            }
        }
    }
}

private val angleOptions = listOf(
    "الأردن / رابطة العالم الإسلامي (18°)" to 18f,
    "أم القرى (18.5°)" to 18.5f,
    "مصر (19.5°)" to 19.5f,
    "أمريكا الشمالية ISNA (15°)" to 15f
)

@Composable
fun Screen() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }

    var enabled by remember { mutableStateOf(prefs.enabled) }
    var mode by remember { mutableIntStateOf(prefs.mode) }
    var angle by remember { mutableFloatStateOf(prefs.fajrAngle) }
    var offset by remember { mutableIntStateOf(prefs.offset) }
    var lat by remember { mutableDoubleStateOf(prefs.lat) }
    var lng by remember { mutableDoubleStateOf(prefs.lng) }
    var hasLoc by remember { mutableStateOf(prefs.hasLocation) }
    var locMsg by remember { mutableStateOf("") }

    fun refreshLocation() {
        LocationHelper.refresh(ctx) { ok ->
            if (ok) {
                lat = prefs.lat; lng = prefs.lng; hasLoc = true
                locMsg = "تم تحديث الموقع"
                Scheduler.scheduleNext(ctx)
            } else {
                locMsg = "تعذر تحديد الموقع. فعّل GPS وامنح الصلاحية"
            }
        }
    }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { refreshLocation() }

    LaunchedEffect(Unit) {
        val needed = buildList {
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isNotEmpty()) permLauncher.launch(needed.toTypedArray()) else refreshLocation()
    }

    val plan = remember(angle, mode, offset, lat, lng, enabled) {
        PrayerCalc.plan(Instant.now(), lat, lng, angle.toDouble(), mode, offset)
    }
    val timeFmt = remember { DateTimeFormatter.ofPattern("HH:mm").withZone(ZoneId.systemDefault()) }
    val dateTimeFmt = remember { DateTimeFormatter.ofPattern("dd/MM  HH:mm").withZone(ZoneId.systemDefault()) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("منبه التهجد", fontSize = 28.sp, fontWeight = FontWeight.Bold)

        Card(Modifier.fillMaxWidth()) {
            Row(
                Modifier.padding(16.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("تفعيل المنبه", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Switch(checked = enabled, onCheckedChange = {
                    enabled = it; prefs.enabled = it; Scheduler.scheduleNext(ctx)
                })
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                if (plan == null) {
                    Text("تعذر حساب الأوقات لهذا الموقع")
                } else {
                    InfoRow("المغرب", timeFmt.format(plan.night.maghrib))
                    InfoRow("منتصف الليل", timeFmt.format(plan.night.midnight))
                    InfoRow("بداية الثلث الأخير", timeFmt.format(plan.night.lastThirdStart))
                    InfoRow("الفجر", timeFmt.format(plan.night.nextFajr))
                    Spacer(Modifier.height(8.dp))
                    InfoRow(
                        "المنبه القادم",
                        if (enabled) dateTimeFmt.format(plan.alarm) else "معطّل"
                    )
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("وقت المنبه", fontWeight = FontWeight.Bold)
                RadioRow("بداية الثلث الأخير من الليل", mode == 0) {
                    mode = 0; prefs.mode = 0; Scheduler.scheduleNext(ctx)
                }
                RadioRow("منتصف الليل", mode == 1) {
                    mode = 1; prefs.mode = 1; Scheduler.scheduleNext(ctx)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    if (offset == 0) "بدون تبكير" else "التبكير: $offset دقيقة قبل الوقت"
                )
                Slider(
                    value = offset.toFloat(),
                    onValueChange = { offset = it.toInt() },
                    onValueChangeFinished = { prefs.offset = offset; Scheduler.scheduleNext(ctx) },
                    valueRange = 0f..60f,
                    steps = 11
                )
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("طريقة حساب الفجر", fontWeight = FontWeight.Bold)
                angleOptions.forEach { (label, value) ->
                    RadioRow(label, angle == value) {
                        angle = value; prefs.fajrAngle = value; Scheduler.scheduleNext(ctx)
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("الموقع", fontWeight = FontWeight.Bold)
                Text(
                    (if (hasLoc) "" else "(افتراضي: عمّان) ") +
                        "%.4f ، %.4f".format(lat, lng)
                )
                if (locMsg.isNotEmpty()) Text(locMsg, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    locMsg = "جاري التحديد..."
                    refreshLocation()
                }) { Text("تحديث الموقع") }
            }
        }

        Button(
            onClick = {
                ContextCompat.startForegroundService(ctx, Intent(ctx, AlarmService::class.java))
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("تجربة المنبه الآن") }

        OutlinedButton(
            onClick = {
                try {
                    ctx.startActivity(
                        Intent(
                            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:${ctx.packageName}")
                        )
                    )
                } catch (_: Exception) {
                    ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("استثناء التطبيق من توفير البطارية (مهم)") }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label)
        Text(value, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun RadioRow(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(8.dp))
        Text(text)
    }
}
