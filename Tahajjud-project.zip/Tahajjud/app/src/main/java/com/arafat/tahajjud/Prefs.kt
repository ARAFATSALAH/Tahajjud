package com.arafat.tahajjud

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("tahajjud", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) = sp.edit().putBoolean("enabled", v).apply()

    /** 0 = الثلث الأخير، 1 = منتصف الليل */
    var mode: Int
        get() = sp.getInt("mode", 0)
        set(v) = sp.edit().putInt("mode", v).apply()

    var fajrAngle: Float
        get() = sp.getFloat("fajrAngle", 18f)
        set(v) = sp.edit().putFloat("fajrAngle", v).apply()

    var offset: Int
        get() = sp.getInt("offset", 0)
        set(v) = sp.edit().putInt("offset", v).apply()

    var snoozeMinutes: Int
        get() = sp.getInt("snooze", 10)
        set(v) = sp.edit().putInt("snooze", v).apply()

    var hasLocation: Boolean
        get() = sp.getBoolean("hasLoc", false)
        set(v) = sp.edit().putBoolean("hasLoc", v).apply()

    // الافتراضي: عمّان
    var lat: Double
        get() = Double.fromBits(sp.getLong("lat", 31.9539.toRawBits()))
        set(v) = sp.edit().putLong("lat", v.toRawBits()).apply()

    var lng: Double
        get() = Double.fromBits(sp.getLong("lng", 35.9106.toRawBits()))
        set(v) = sp.edit().putLong("lng", v.toRawBits()).apply()
}
