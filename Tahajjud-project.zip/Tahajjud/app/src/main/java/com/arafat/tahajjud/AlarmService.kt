package com.arafat.tahajjud

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.flow.MutableStateFlow

class AlarmService : Service() {

    companion object {
        const val ACTION_STOP = "com.arafat.tahajjud.STOP"
        const val ACTION_SNOOZE = "com.arafat.tahajjud.SNOOZE"
        private const val CHANNEL = "tahajjud_alarm"
        private const val NOTIF_ID = 77
        val active = MutableStateFlow(false)
    }

    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopAlarm(); return START_NOT_STICKY }
            ACTION_SNOOZE -> {
                Scheduler.scheduleSnooze(this, Prefs(this).snoozeMinutes)
                stopAlarm()
                return START_NOT_STICKY
            }
        }
        active.value = true
        startInForeground()
        startSound()
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ stopAlarm() }, 5 * 60_000L)
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL, "منبه التهجد", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null)
            enableVibration(false)
        }
        nm.createNotificationChannel(ch)

        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val fullScreen = PendingIntent.getActivity(
            this, 20,
            Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            flags
        )
        val stop = PendingIntent.getService(
            this, 21, Intent(this, AlarmService::class.java).setAction(ACTION_STOP), flags
        )
        val snooze = PendingIntent.getService(
            this, 22, Intent(this, AlarmService::class.java).setAction(ACTION_SNOOZE), flags
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("حان وقت التهجد")
            .setContentText("اضغط لفتح شاشة المنبه")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setContentIntent(fullScreen)
            .setFullScreenIntent(fullScreen, true)
            .addAction(0, "إيقاف", stop)
            .addAction(0, "غفوة", snooze)
            .build()
        ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
    }

    private fun startSound() {
        releasePlayer()
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@AlarmService, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (_: Exception) { }
        try {
            vibrator = if (Build.VERSION.SDK_INT >= 31)
                getSystemService(VibratorManager::class.java).defaultVibrator
            else
                @Suppress("DEPRECATION") getSystemService(Vibrator::class.java)
            vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0))
        } catch (_: Exception) { }
    }

    private fun releasePlayer() {
        try { player?.stop() } catch (_: Exception) { }
        player?.release()
        player = null
    }

    private fun stopAlarm() {
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        vibrator?.cancel()
        active.value = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        releasePlayer()
        vibrator?.cancel()
        active.value = false
        super.onDestroy()
    }
}
